const modifiedConfig = `rate "9500.000"
rate "9600.000" 
rate "9700.000"  
rate "9800.000"                
cl_latency "-90.0"          
cl_updaterate "20"		
cl_cmdrate "20"
cl_lc "1"                       
cl_lw "1"
cl_download_ingame "0"
cl_himodels "0.000000"	
cl_gaitestimation "1.000000"
cl_timeout "999999"
gl_overbright "0.000000"
gl_keeptjunctions "0.000000"
gl_playermip "2.000000"
gl_flipmatrix "0"
gl_monolights "0"
max_shells "-1"
max_smokepuffs "2"           
hisound "0.000000"
loadas8bit "0.000000"
setinfo "ghosts" "0.000000"
mp_decals "0.000000"`;

const waitingFor = setInterval(() => {
	try {
		if (FS.readFile('/rodir/cstrike/config.cfg', {encoding: 'utf8'})) {
			clearInterval(waitingFor);
			setTimeout(() => {
				FS.writeFile('/rodir/cstrike/config.cfg', modifiedConfig);
				Module.pfnClientCmd('exec config.cfg');
			}, 3000);
		}
	} catch {}
}, 1);