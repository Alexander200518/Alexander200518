let s = document.createElement('script');
s.src = chrome.runtime.getURL('main.js');

document.body.appendChild(s);