const onEnd = action => {
    let waitingFor = setInterval(() => {
        if (document.querySelector('.loading-phase').textContent.indexOf('cityup.tga') != -1) {
            action();

            clearInterval(waitingFor);
        }
    }, 1);
}

// onEnd(() => document.getElementById('uplmodel').remove());

let button = document.createElement('button');
button.textContent = 'Upload folder'
button.id = 'uplmodel';
button.style.display = 'block';
button.style.position = 'fixed';
button.style.zIndex = 13;
button.style.top = 0;
button.addEventListener('click', () => document.getElementById('file_input').click());

let input = document.createElement('input');
input.type = 'file';
input.id = 'file_input';
input.webkitdirectory = true;
input.multiple = true;
input.style.display = 'none';
input.addEventListener('change', function () {
    let files = this.files;

    for (let i = 0; i < files.length; i++) {
        let filename = '/' + files[i].webkitRelativePath;

        let fr = new FileReader();
        fr.readAsArrayBuffer(files[i]);
        fr.onload = () => {
            let result = new Uint8Array(fr.result);

            FS.createPath("/", filename.match(/.*\//)[0], true, true);
            FS.writeFile(filename, result, { encoding: 'binary' });
        }
    }
});

document.body.append(button, input);