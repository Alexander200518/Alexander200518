let s = document.createElement('script');
s.src = chrome.runtime.getURL('script.js');

document.body.appendChild(s);